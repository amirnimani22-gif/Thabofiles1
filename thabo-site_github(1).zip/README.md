# Thabo-Site mit Login, Rangliste und Handel

## Aufbau
- `public/index.html`: die Seite (Case, Shop, Inventar, Arena, Rangliste, Handel).
- `netlify/functions/api.mjs`: Server-Funktion unter `/api/<aktion>`. Speichert Konten, Inventare und Angebote mit Netlify Blobs.
- `netlify/lib/config.mjs`: Items, Seltenheiten, Case-Gewichte und Preise. Aus der Seite erzeugt. Wenn du dort etwas änderst, muss das hier auch stimmen.
- `netlify.toml`, `package.json`: Netlify-Einstellungen.

## Deployen
1. Ordner in ein Git-Repository legen (z. B. GitHub).
2. In Netlify „Add new site → Import an existing project“ und das Repository wählen. Build-Befehl leer lassen, Publish-Ordner steht schon in `netlify.toml`.
3. Netlify installiert `@netlify/blobs` aus der `package.json`. Ob Netlify Blobs und Functions in deinem Plan aktiv sind, prüfst du in den Site-Einstellungen.

Lokal testen geht mit der Netlify CLI (`netlify dev`).

## Bekannte Grenzen (v1)
- **Münzen aus Mini-Spielen** (Arena, Dame, Daumen hoch, Geheimcodes) meldet der Browser an den Server (`earn`, höchstens 2000 pro Aufruf). Das lässt sich über die API ausnutzen. Sauber wird es erst, wenn diese Belohnungen auch auf dem Server geprüft werden.
- **Admin-Schalter** (unendlich Coins/Cases) wirken nur im Browser, der Server ignoriert sie.
- **Passwörter** werden mit scrypt gehasht. Es gibt noch kein Rate-Limit und keinen Passwort-Reset.
- **Handel ohne Transaktion:** Blobs kennen keine Transaktionen. Bei gleichzeitigen Aktionen kann es theoretisch zu Doppelbuchungen kommen.
- **Alte Inventare** aus dem Browser (localStorage) werden nicht übernommen.
- **Rangliste** lädt alle Konten, zeigt die besten 50. Bei vielen Spielern sollte man das später optimieren.
- **Medien:** Bilder, Audio und Videos liegen als Dateien in `public/media/` (nicht mehr in index.html).

## Admin-Bereich
- Anmelden mit Name **028342** und Passwort **028342**.
- Optional: In Netlify unter *Site configuration → Environment variables* die Variable `ADMIN_PASSWORD` setzen. Dann gilt dieses Passwort statt 028342 (danach neu deployen).
- Im Profil erscheint dann der Button „Adminbereich“: Konten sperren/entsperren, Coins setzen, Konten löschen.
- Der Name 028342 ist für normale Accounts gesperrt.

## Profilbild und Konto löschen
- Profilbild im Profil hochladen. Das Bild wird auf 160×160 verkleinert und als JPEG gespeichert.
- Account löschen geht im Profil, mit Passwort zur Bestätigung. Dabei werden auch Items, Coins und offene Angebote gelöscht.

## Admin-Items für Cases
- Im Adminbereich unter „Items für Cases“: Name, Seltenheit und Datei (Bild oder MP4-Clip, max. 4 MB) wählen und hinzufügen.
- Bilder werden auf 1024 px verkleinert, Clips bleiben unverändert. Die Vorschau wird automatisch erzeugt.
- Die Items liegen in Netlify Blobs auf dem Server, nicht im Code. Sie bleiben also bei neuen Deploys erhalten. Die Basis-Items im Code bleiben unverändert.
- Löschen entfernt ein Item für alle Spieler.
- Items landen in allen Cases gemäß ihrer Seltenheit. Die Gewichte pro Case bleiben wie sie sind.

## Roulette (Multiplayer)
- Eine Runde alle 10 Minuten. Wetten sind bis 30 Sekunden vor dem Drehen offen.
- Setzen geht mit Coins, Einsätze von 1 bis 5.000 Coins pro Wette, höchstens 20.000 Coins pro Runde und Spieler.
- Wettarten: einzelne Zahl (35:1), Rot/Schwarz, Gerade/Ungerade, 1–18/19–36 (1:1), Dutzende und Spalten (2:1). Bei der 0 verlieren die Außenwetten.
- Das Ergebnis berechnet der Server aus einem geheimen Schlüssel, der in Netlify Blobs liegt. Der Browser kann es nicht vorher sehen.
- Die Auszahlung passiert, sobald jemand nach Rundenende den Tisch abruft. Wenn gerade niemand online ist, passiert sie beim nächsten Abruf.
- Die Arena wurde durch den Tisch ersetzt. Der Tisch ist unterhalb des Spiele-Shops, nicht im oberen Menü.
- Zum Testen lassen sich die Zeiten über `ROULETTE_ROUND_MS` und `ROULETTE_LOCK_MS` verkürzen (Millisekunden). Im Betrieb nicht setzen.
- Bekannte Grenze: Coins werden bei Einsatz und Auszahlung über den gleichen Konto-Datensatz geschrieben. Bei gleichzeitigen Aktionen desselben Spielers kann ein Schreibvorgang einen anderen überschreiben.

## Neue Spieler
Starten mit 150 Coins und 2 Standard-Cases.
