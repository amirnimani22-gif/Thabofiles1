import { getStore } from "@netlify/blobs";
import { scrypt, randomBytes, randomUUID, timingSafeEqual, createHmac } from "node:crypto";
import { promisify } from "node:util";
import { ITEMS as BASE_ITEMS, SV, CASES, START_COINS, START_CASES } from "../lib/config.mjs";

// Laufende Liste: Basis-Items aus der Konfiguration plus Admin-Items aus dem Speicher
const ITEMS = [...BASE_ITEMS];

const scryptAsync = promisify(scrypt);
const ITEM = new Map(ITEMS.map((i) => [i.id, i]));
const ADMIN_NAME = "028342";
const ADMIN_DEFAULT_PW = "028342"; // wird durch die Umgebungsvariable ADMIN_PASSWORD überschrieben, falls gesetzt
const PUBLIC = new Set(["register", "login", "users", "inventory", "leaderboard", "items"]);
const ADMIN_ONLY = new Set(["adminUsers", "adminBan", "adminDelete", "adminCoins", "adminItemAdd", "adminItemDelete"]);
const ITEM_MEDIA_RE = { i: /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/, v: /^data:video\/mp4;base64,[A-Za-z0-9+/=]+$/ };
const THUMB_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/;
const ADMIN_OK = new Set(["me", "logout", "users", "leaderboard", ...ADMIN_ONLY]);
const NAME_RE = /^[\p{L}\p{N}_-]{3,16}$/u;
const AVATAR_MAX = 300000; // Zeichen, also rund 220 KB Bild
const AVATAR_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;

// ---- Roulette ----
// Test kann die Zeiten über Umgebungsvariablen verkürzen. Im Betrieb gelten die Standardwerte.
const ROUND_MS = Number(process.env.ROULETTE_ROUND_MS) || 600000; // eine Runde alle 10 Minuten
const LOCK_MS = Number(process.env.ROULETTE_LOCK_MS) || 30000;    // Wetten schließen 30 s vor dem Drehen
const WHEEL_ORDER = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
const RED_NUMS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
const BET_MULT = { number: 35, red: 1, black: 1, even: 1, odd: 1, low: 1, high: 1, dozen: 2, col: 2 };
const MAX_BET = 5000;
const MAX_ROUND_TOTAL = 20000;
function roundTimes(k) {
  const start = k * ROUND_MS;
  return { id: k, close: start + ROUND_MS - LOCK_MS, end: start + ROUND_MS };
}
function phaseOf(t, now) { return now < t.close ? "open" : now < t.end ? "spinning" : "settled"; }
function rouletteWins(type, value, r) {
  if (type === "number") return Number(value) === r;
  if (r === 0) return false; // Außenwetten verlieren bei der 0
  switch (type) {
    case "red": return RED_NUMS.has(r);
    case "black": return !RED_NUMS.has(r);
    case "even": return r % 2 === 0;
    case "odd": return r % 2 === 1;
    case "low": return r <= 18;
    case "high": return r >= 19;
    case "dozen": return Math.ceil(r / 12) === Number(value);
    case "col": return ((r - 1) % 3) + 1 === Number(value);
    default: return false;
  }
}
function normBet(type, value) {
  if (!Object.prototype.hasOwnProperty.call(BET_MULT, type)) return null;
  if (type === "number") { const n = Number(value); return Number.isInteger(n) && n >= 0 && n <= 36 ? String(n) : null; }
  if (type === "dozen" || type === "col") { const n = Number(value); return [1, 2, 3].includes(n) ? String(n) : null; }
  return "";
}
// Ergebnis kommt aus einem geheimen Schlüssel auf dem Server und ist für jede Runde fest
function resultOf(secret, k) {
  return createHmac("sha256", secret).update("round:" + k).digest().readUInt32BE(0) % 37;
}

const fail = (status, error) => ({ status, body: { error } });
const done = (body) => ({ status: 200, body });
const inc = (obj, id, n = 1) => { obj[id] = (obj[id] | 0) + n; };
const dec = (obj, id, n = 1) => { obj[id] = (obj[id] | 0) - n; if (obj[id] <= 0) delete obj[id]; };
const isCount = (n) => Number.isInteger(n) && n > 0;
const bearer = (req) => {
  const h = req.headers.get("authorization") || "";
  return h.startsWith("Bearer ") ? h.slice(7) : "";
};

async function hashPw(pw, salt) {
  return (await scryptAsync(pw, salt, 32)).toString("hex");
}

function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && timingSafeEqual(x, y);
}

function publicState(u) {
  if (u.admin) return { name: ADMIN_NAME, admin: true, coins: 0, cases: {}, inv: {}, avatar: null };
  return { name: u.name, admin: false, coins: u.coins, cases: u.cases, inv: u.inv, avatar: u.avatar || null };
}

function pickItem(weights) {
  const ws = weights.map((w, r) => (ITEMS.some((i) => i.r === r) ? w : 0));
  const sum = ws.reduce((a, b) => a + b, 0);
  if (!sum) return ITEMS[Math.floor(Math.random() * ITEMS.length)];
  let x = Math.random() * sum;
  let r = 0;
  for (; r < 5; r++) { if (x < ws[r]) break; x -= ws[r]; }
  let pool = ITEMS.filter((i) => i.r === r);
  if (!pool.length) pool = ITEMS;
  return pool[Math.floor(Math.random() * pool.length)];
}

function value(u) {
  let v = u.coins;
  for (const [id, c] of Object.entries(u.inv)) {
    const it = ITEM.get(id);
    if (it) v += SV[it.r] * c;
  }
  return v;
}

// Admin-Items aus dem Speicher in die laufende Liste übernehmen (bleibt über Deploys erhalten)
async function refreshCustom(store) {
  const { blobs } = await store.list({ prefix: "itemmeta:" });
  const custom = (await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })))).filter(Boolean);
  ITEMS.length = 0;
  ITEMS.push(...BASE_ITEMS, ...custom);
  ITEM.clear();
  for (const i of ITEMS) ITEM.set(i.id, i);
}

export function createHandler(store) {
  const key = (name) => "user:" + name.toLowerCase();
  const getUser = (name) => store.get(key(name), { type: "json" });
  const saveUser = (u) => store.setJSON(key(u.name), u);
  const allUsers = async () => {
    const { blobs } = await store.list({ prefix: "user:" });
    return Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
  };
  const allTrades = async () => {
    const { blobs } = await store.list({ prefix: "trade:" });
    return Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
  };
  const newSession = async (name, admin = false) => {
    const token = randomBytes(24).toString("hex");
    await store.setJSON("sess:" + token, { name, admin, created: Date.now() });
    return token;
  };
  // Alle Sitzungen eines Accounts beenden
  async function dropSessions(name) {
    const { blobs } = await store.list({ prefix: "sess:" });
    for (const b of blobs) {
      const s = await store.get(b.key, { type: "json" });
      if (s && !s.admin && s.name.toLowerCase() === name.toLowerCase()) await store.delete(b.key);
    }
  }
  // Account samt Sitzungen löschen, offene Angebote daran werden abgebrochen
  async function removeAccount(name) {
    await dropSessions(name);
    for (const t of await allTrades()) {
      if (t && t.status === "open" && (t.from.toLowerCase() === name.toLowerCase() || t.to.toLowerCase() === name.toLowerCase())) {
        t.status = "cancelled";
        await store.setJSON("trade:" + t.id, t);
      }
    }
    await store.delete(key(name));
  }
  // Wer ist angemeldet? Gibt Status und Nutzer zurück.
  async function resolve(token) {
    if (!token) return { status: 401 };
    const s = await store.get("sess:" + token, { type: "json" });
    if (!s) return { status: 401 };
    if (s.admin) return { user: { name: ADMIN_NAME, admin: true } };
    const u = await getUser(s.name);
    if (!u) return { status: 401 };
    if (u.banned) return { status: 403, error: "Dieser Account ist gesperrt" };
    return { user: u };
  }
  async function roundSecret() {
    let s = await store.get("roulette:secret", { type: "json" });
    if (!s) {
      await store.setJSON("roulette:secret", { k: randomBytes(32).toString("hex") });
      s = await store.get("roulette:secret", { type: "json" });
    }
    return s.k;
  }
  async function listBets(k) {
    const { blobs } = await store.list({ prefix: "bet:" + k + ":" });
    const items = (await Promise.all(blobs.map(async (b) => ({ key: b.key, bet: await store.get(b.key, { type: "json" }) })))).filter((x) => x.bet);
    return items.sort((a, b) => a.bet.created - b.bet.created);
  }
  // Auszahlung einer abgelaufenen Runde. Ein Claim-Token verhindert doppelte Auszahlung bei gleichzeitigen Anfragen.
  async function settleRound(k, secret) {
    if (await store.get("rset:" + k, { type: "json" })) return;
    const token = randomBytes(8).toString("hex");
    await store.setJSON("rclaim:" + k, { token });
    await new Promise((res) => setTimeout(res, 200));
    const c = await store.get("rclaim:" + k, { type: "json" });
    if (!c || c.token !== token) return;
    const r = resultOf(secret, k);
    await store.setJSON("rset:" + k, { result: r, at: Date.now() });
    const bets = await listBets(k);
    const credit = new Map();
    for (const { bet } of bets) {
      if (rouletteWins(bet.type, bet.value, r)) {
        credit.set(bet.user, (credit.get(bet.user) || 0) + bet.amount * (BET_MULT[bet.type] + 1));
      }
    }
    for (const [name, amount] of credit) {
      const u = await getUser(name);
      if (u) { u.coins += amount; await saveUser(u); }
    }
    for (const { key } of bets) await store.delete(key);
  }

  async function finish(id, user, side, status) {
    const t = await store.get("trade:" + String(id), { type: "json" });
    if (!t || t[side] !== user.name || t.status !== "open") return fail(404, "Angebot nicht mehr verfügbar");
    t.status = status;
    await store.setJSON("trade:" + t.id, t);
    return done(t);
  }

  const actions = {
    async register({ body }) {
      const name = String(body.name || "").trim();
      const pw = String(body.pw || "");
      if (!NAME_RE.test(name)) return fail(400, "Name: 3–16 Zeichen, nur Buchstaben, Zahlen, _ oder -");
      if (name.toLowerCase() === ADMIN_NAME) return fail(409, "Dieser Name ist reserviert");
      if (pw.length < 6 || pw.length > 200) return fail(400, "Passwort: 6 bis 200 Zeichen");
      if (await getUser(name)) return fail(409, "Name ist schon vergeben");
      const salt = randomBytes(16).toString("hex");
      const u = { name, salt, hash: await hashPw(pw, salt), coins: START_COINS, cases: { ...START_CASES }, inv: {}, created: Date.now() };
      await saveUser(u);
      const token = await newSession(name);
      return done({ token, ...publicState(u) });
    },

    async login({ body }) {
      const name = String(body.name || "").trim();
      const pw = String(body.pw || "");
      if (name.toLowerCase() === ADMIN_NAME) {
        const adminPw = process.env.ADMIN_PASSWORD || ADMIN_DEFAULT_PW;
        if (!safeEqual(pw, adminPw)) return fail(401, "Name oder Passwort falsch");
        const token = await newSession(ADMIN_NAME, true);
        return done({ token, ...publicState({ admin: true }) });
      }
      const u = await getUser(name);
      if (!u) return fail(401, "Name oder Passwort falsch");
      const h = await hashPw(pw, u.salt);
      if (!safeEqual(h, u.hash)) return fail(401, "Name oder Passwort falsch");
      if (u.banned) return fail(403, "Dieser Account ist gesperrt");
      const token = await newSession(u.name);
      return done({ token, ...publicState(u) });
    },

    async me({ user }) { return done(publicState(user)); },

    async logout({ token }) {
      await store.delete("sess:" + token);
      return done({ ok: true });
    },

    async open({ body, user }) {
      const c = body.case;
      if (!CASES[c]) return fail(400, "Unbekannte Case");
      if (!(user.cases[c] > 0)) return fail(400, "Keine Case dieser Art. Kaufe eine im Shop.");
      user.cases[c] -= 1;
      const item = pickItem(CASES[c].w);
      inc(user.inv, item.id);
      await saveUser(user);
      return done({ ...publicState(user), id: item.id });
    },

    async buy({ body, user }) {
      const c = body.case;
      if (!CASES[c]) return fail(400, "Unbekannte Case");
      if (user.coins < CASES[c].p) return fail(400, "Nicht genug Coins");
      user.coins -= CASES[c].p;
      user.cases[c] = (user.cases[c] | 0) + 1;
      await saveUser(user);
      return done(publicState(user));
    },

    async sell({ body, user }) {
      const it = ITEM.get(body.id);
      if (!it) return fail(400, "Unbekanntes Item");
      const have = user.inv[body.id] | 0;
      let n = Number(body.n);
      if (!isCount(n)) return fail(400, "Ungültige Anzahl");
      n = Math.min(n, have);
      if (n < 1) return fail(400, "Nicht im Inventar");
      dec(user.inv, body.id, n);
      user.coins += n * SV[it.r];
      await saveUser(user);
      return done(publicState(user));
    },

    async sellDupes({ user }) {
      let gained = 0;
      for (const [id, c] of Object.entries(user.inv)) {
        const it = ITEM.get(id);
        if (it && c > 1) { gained += (c - 1) * SV[it.r]; user.inv[id] = 1; }
      }
      if (!gained) return fail(400, "Keine Doppelten vorhanden.");
      user.coins += gained;
      await saveUser(user);
      return done({ ...publicState(user), gained });
    },

    // Münzen aus den Mini-Spielen. Dieser Weg ist nur begrenzt sicher, siehe README.
    async earn({ body, user }) {
      const amount = Number(body.amount);
      if (!Number.isInteger(amount) || amount < 1 || amount > 2000) return fail(400, "Ungültiger Betrag");
      user.coins += amount;
      await saveUser(user);
      return done(publicState(user));
    },

    async avatar({ body, user }) {
      if (body.data === null || body.data === "") {
        delete user.avatar;
      } else {
        const data = String(body.data);
        if (!AVATAR_RE.test(data)) return fail(400, "Ungültiges Bild (nur JPEG, PNG oder WebP)");
        if (data.length > AVATAR_MAX) return fail(413, "Bild ist zu groß");
        user.avatar = data;
      }
      await saveUser(user);
      return done(publicState(user));
    },

    async deleteAccount({ body, user }) {
      const h = await hashPw(String(body.pw || ""), user.salt);
      if (!safeEqual(h, user.hash)) return fail(401, "Passwort falsch");
      await removeAccount(user.name);
      return done({ ok: true });
    },

    async users({ body }) {
      const q = String(body.q || "").trim().toLowerCase();
      const names = (await allUsers()).filter((u) => !u.banned).map((u) => u.name)
        .filter((n) => n.toLowerCase().includes(q)).slice(0, 10);
      return done({ names });
    },

    async inventory({ body }) {
      const u = await getUser(String(body.name || "").trim());
      if (!u || u.banned) return fail(404, "Spieler nicht gefunden");
      return done({ name: u.name, inv: u.inv });
    },

    async leaderboard() {
      const rows = (await allUsers()).filter((u) => !u.banned).map((u) => ({
        name: u.name,
        value: value(u),
        items: Object.values(u.inv).reduce((a, b) => a + b, 0),
        avatar: u.avatar || null,
      }));
      rows.sort((a, b) => b.value - a.value);
      return done({ rows: rows.slice(0, 50) });
    },

    async trades({ user }) {
      const mine = (await allTrades()).filter((t) => t && (t.from === user.name || t.to === user.name));
      const newest = (a, b) => b.created - a.created;
      return done({
        incoming: mine.filter((t) => t.status === "open" && t.to === user.name).sort(newest),
        outgoing: mine.filter((t) => t.status === "open" && t.from === user.name).sort(newest),
        history: mine.filter((t) => t.status !== "open").sort(newest).slice(0, 20),
      });
    },

    async offer({ body, user }) {
      const to = await getUser(String(body.to || "").trim());
      if (!to || to.banned) return fail(404, "Spieler nicht gefunden");
      if (to.name === user.name) return fail(400, "Du kannst nicht mit dir selbst handeln");
      if (!ITEM.has(body.give) || !ITEM.has(body.want)) return fail(400, "Unbekanntes Item");
      if (!(user.inv[body.give] > 0)) return fail(400, "Du hast dieses Item nicht");
      if (!(to.inv[body.want] > 0)) return fail(400, "Der Spieler hat dieses Item nicht");
      const t = {
        id: randomUUID(), from: user.name, to: to.name,
        give: body.give, want: body.want, status: "open", created: Date.now(),
      };
      await store.setJSON("trade:" + t.id, t);
      return done(t);
    },

    async accept({ body, user }) {
      const t = await store.get("trade:" + String(body.id), { type: "json" });
      if (!t || t.to !== user.name || t.status !== "open") return fail(404, "Angebot nicht mehr verfügbar");
      const from = await getUser(t.from);
      if (!from || from.banned || !(from.inv[t.give] > 0) || !(user.inv[t.want] > 0)) {
        t.status = "failed";
        await store.setJSON("trade:" + t.id, t);
        return fail(400, "Ein Item fehlt nicht mehr im Inventar");
      }
      dec(from.inv, t.give); inc(user.inv, t.give);
      dec(user.inv, t.want); inc(from.inv, t.want);
      t.status = "done";
      await saveUser(from);
      await saveUser(user);
      await store.setJSON("trade:" + t.id, t);
      return done(publicState(user));
    },

    async decline({ body, user }) { return finish(body.id, user, "to", "declined"); },
    async cancel({ body, user }) { return finish(body.id, user, "from", "cancelled"); },

    // Items für alle Spieler (Basis-Items sind schon in der Seite, hier nur die Admin-Items)
    async items() {
      const out = [];
      for (const it of ITEMS.filter((i) => i.custom)) {
        const m = await store.get("itemmedia:" + it.id, { type: "json" });
        if (m) out.push({ id: it.id, n: it.n, t: it.t, r: it.r, s: m.s, h: m.h });
      }
      return done({ items: out });
    },

    async adminItemAdd({ body }) {
      const n = String(body.n || "").trim().slice(0, 40);
      const t = body.t;
      const r = Number(body.r);
      const s = String(body.s || "");
      const h = String(body.h || "");
      if (!n) return fail(400, "Name fehlt");
      if (t !== "i" && t !== "v") return fail(400, "Typ muss Bild oder Clip sein");
      if (!Number.isInteger(r) || r < 0 || r > 5) return fail(400, "Ungültige Seltenheit");
      if (!ITEM_MEDIA_RE[t].test(s)) return fail(400, t === "i" ? "Bild ungültig" : "Clip muss MP4 sein");
      if (s.length > 6000000) return fail(413, "Datei ist zu groß (max. ca. 4 MB)");
      if (!THUMB_RE.test(h) || h.length > 300000) return fail(400, "Vorschau ungültig");
      const id = "adm-" + randomUUID().slice(0, 8);
      await store.setJSON("itemmeta:" + id, { id, n, t, r, custom: true, created: Date.now() });
      await store.setJSON("itemmedia:" + id, { s, h });
      return done({ ok: true, id });
    },

    async adminItemDelete({ body }) {
      const id = String(body.id || "");
      if (!id.startsWith("adm-")) return fail(400, "Nur Admin-Items können gelöscht werden");
      await store.delete("itemmeta:" + id);
      await store.delete("itemmedia:" + id);
      return done({ ok: true });
    },

    // ---- Roulette ----
    async roulette({ user }) {
      const now = Date.now();
      const k = Math.floor(now / ROUND_MS);
      const secret = await roundSecret();
      for (const kk of [k - 1, k - 2]) {
        if (kk >= 0 && roundTimes(kk).end <= now) await settleRound(kk, secret);
      }
      const t = roundTimes(k);
      const phase = phaseOf(t, now);
      const bets = await listBets(k);
      const players = new Map();
      for (const { bet } of bets) {
        const p = players.get(bet.user) || { name: bet.user, total: 0, count: 0 };
        p.total += bet.amount;
        p.count += 1;
        players.set(bet.user, p);
      }
      const mine = bets.map((x) => x.bet).filter((b) => b.user === user.name);
      const history = [];
      for (let kk = k - 1; kk >= 0 && kk >= k - 10; kk--) history.push({ id: kk, result: resultOf(secret, kk) });
      return done({
        ...publicState(user),
        round: { id: k, phase, close: t.close, end: t.end, now, result: phase === "open" ? null : resultOf(secret, k) },
        players: [...players.values()].sort((a, b) => b.total - a.total),
        mine: { total: mine.reduce((a, b) => a + b.amount, 0), bets: mine.map((b) => ({ type: b.type, value: b.value, amount: b.amount })) },
        history,
      });
    },

    async rouletteBet({ body, user }) {
      const now = Date.now();
      const k = Math.floor(now / ROUND_MS);
      if (phaseOf(roundTimes(k), now) !== "open") return fail(400, "Wetten sind für diese Runde geschlossen");
      const value = normBet(body.type, body.value);
      if (value === null) return fail(400, "Ungültige Wette");
      const amount = Number(body.amount);
      if (!Number.isInteger(amount) || amount < 1 || amount > MAX_BET) return fail(400, "Einsatz zwischen 1 und " + MAX_BET + " Coins");
      if (user.coins < amount) return fail(400, "Nicht genug Coins");
      const already = (await listBets(k)).filter((x) => x.bet.user === user.name).reduce((a, x) => a + x.bet.amount, 0);
      if (already + amount > MAX_ROUND_TOTAL) return fail(400, "Limit pro Runde: " + MAX_ROUND_TOTAL + " Coins");
      user.coins -= amount;
      await saveUser(user);
      await store.setJSON("bet:" + k + ":" + randomUUID(), { round: k, user: user.name, type: String(body.type), value, amount, created: now });
      return done(publicState(user));
    },

    // ---- Admin ----
    async adminUsers() {
      const users = (await allUsers()).map((u) => ({
        name: u.name,
        coins: u.coins,
        items: Object.values(u.inv).reduce((a, b) => a + b, 0),
        banned: !!u.banned,
        created: u.created || 0,
      })).sort((a, b) => b.created - a.created);
      return done({ users });
    },

    async adminBan({ body }) {
      const name = String(body.name || "");
      const u = await getUser(name);
      if (!u) return fail(404, "Account nicht gefunden");
      u.banned = !!body.banned;
      await saveUser(u);
      if (u.banned) await dropSessions(u.name);
      return done({ ok: true });
    },

    async adminDelete({ body }) {
      const name = String(body.name || "");
      if (!(await getUser(name))) return fail(404, "Account nicht gefunden");
      await removeAccount(name);
      return done({ ok: true });
    },

    async adminCoins({ body }) {
      const name = String(body.name || "");
      const amount = Number(body.amount);
      const u = await getUser(name);
      if (!u) return fail(404, "Account nicht gefunden");
      if (!Number.isInteger(amount) || amount < 0 || amount > 1e9) return fail(400, "Ungültiger Betrag");
      u.coins = amount;
      await saveUser(u);
      return done({ ok: true });
    },
  };

  return async function handle(req, action) {
    if (req.method !== "POST") return fail(405, "Nur POST");
    if (!Object.prototype.hasOwnProperty.call(actions, action)) return fail(404, "Unbekannte Aktion");
    await refreshCustom(store);
    let body = {};
    try { body = (await req.json()) || {}; } catch { body = {}; }
    const token = bearer(req);
    let user = null;
    if (!PUBLIC.has(action)) {
      const r = await resolve(token);
      if (!r.user) return fail(r.status || 401, r.error || "Bitte einloggen");
      user = r.user;
      if (user.admin && !ADMIN_OK.has(action)) return fail(403, "Dieser Bereich ist für Admins gesperrt");
      if (!user.admin && ADMIN_ONLY.has(action)) return fail(403, "Nur für Admins");
      if (user.admin && ["open", "buy", "sell", "sellDupes", "earn", "avatar", "deleteAccount", "offer", "accept", "decline", "cancel", "trades"].includes(action)) {
        return fail(403, "Admin-Konto hat kein Inventar");
      }
    }
    try {
      return await actions[action]({ body, user, token });
    } catch (e) {
      console.error(e);
      return fail(500, "Serverfehler");
    }
  };
}

export default async (req, context) => {
  const handle = createHandler(getStore("thabo"));
  const { status, body } = await handle(req, context.params.action);
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
};

export const config = { path: "/api/:action" };
